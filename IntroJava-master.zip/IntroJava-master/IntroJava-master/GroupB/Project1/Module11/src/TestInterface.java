public class TestInterface extends Object implements Interface,Interface1 {


    public static void main (String[] args) {
        TestInterface o = new TestInterface();
        o.method1("Method 1");
        o.method2("Method 2");
        System.out.println("Method3 "+  o.method3());
        o.method4("Method 4");
        o.method5("Method 5");
        o.method6();
    }

    @Override
    public void method1(String s) {
        System.out.println(s);
    }

    @Override
    public void method2(String s) {
        System.out.println(s);
    }

    @Override
    public double method3() {
        return 2.5;
    }

    @Override
    public void method4(String s) {
        System.out.println(s);
    }

    @Override
    public void method5(String s) {
        System.out.println(s);
    }
}
