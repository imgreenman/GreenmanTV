public interface Interface1 {
    public void method4(String s);
    public void method5(String s);
    default void method6() {
        System.out.println("Default Interface method");
    }
}
