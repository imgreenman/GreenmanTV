public interface Interface {
    public void method1(String s);
    public void method2(String s);
    public double method3();
}
