// BasePlusCommissionEmployeeTest.java
// Testing class BasePlusCommissionEmployee.

public class BasePlusCommissionEmployeeTest
{
   public static void main(String[] args) {
       // instantiate BasePlusCommissionEmployee object
       BasePlusCommissionEmployee employee =
               new BasePlusCommissionEmployee(
                       "Bob", "Lewis", "333-33-3333", 5000, .04, 300);

       System.out.printf("%n%s:%n%n%s%n",
               "Updated employee information obtained by toString", employee);
       System.out.println("Earning " + Double.toString(employee.earnings()));


       // instantiate BasePlusCommissionEmployee object
       CommissionEmployee employee1 =
               new CommissionEmployee(
                       "Bobby", "L", "444", 15000, .1);

       System.out.printf("%n%s:%n%n%s%n",
               "Updated employee information obtained by toString", employee1);
       System.out.println("Earning " + Double.toString(employee1.earnings()));


   }

} // end class BasePlusCommissionEmployeeTest


/**************************************************************************
 * (C) Copyright 1992-2014 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
