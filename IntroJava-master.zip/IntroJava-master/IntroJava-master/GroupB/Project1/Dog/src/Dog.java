public class Dog{
 private    String breed;
 private    int ageC;
 private    String color;
 private    String name;
 public  static  int legs = 4;

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public void setAgeC(int ageC) {
        this.ageC = ageC;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAgeC() {
        return ageC;
    }

    public String getColor() {
        int i = 7;
        return color;
    }

    public String getName() {
        return name;
    }

    public Dog() {
     this.breed = "Not Defined";
     this.ageC = 0;
     this.color ="Not defined";
     this.name = "Not defined";
 }
 public Dog(String breed, int ageC, String color, String name) {
     this.breed = breed;
     this.ageC = ageC;
     this.color = color;
     this.name = name;
 }

 public void barking(){
        System.out.print(breed+" Barking\n");
    }
 public void hungry(){
        System.out.print(breed+ " Hungry\n");
    }
 public void sleeping(){
        System.out.print(breed + " sleeping\n");
    }
}
