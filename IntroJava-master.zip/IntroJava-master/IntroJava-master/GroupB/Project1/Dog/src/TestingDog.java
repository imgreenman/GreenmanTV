public class TestingDog {
    public static void main(String[] args) {
        System.out.print("Starting Main\n");
        Dog d = new Dog("Irish Wolfhound", 6, "Brown", "Nelson");
        Dog d1 = new Dog("Bull dog", 900, "green", "May");
        d.sleeping();
        d.hungry();
        d.barking();
        d1.sleeping();
        d1.hungry();
        d1.barking();
        d1.setAgeC(8);
        d.setAgeC(78);
        System.out.print(d.getBreed() + " " + d.getAgeC() + "  static " + Dog.legs);

    }
}
