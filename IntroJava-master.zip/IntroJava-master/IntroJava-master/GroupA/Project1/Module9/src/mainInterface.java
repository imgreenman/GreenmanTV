public class mainInterface extends Object implements Interface,Interface1 {

    public static void main (String [] args) {
        mainInterface o = new mainInterface();
        o.hello("hello");
        o.goodbye("goodbye");
        o.testInterface("Testinging Interface 1");
        o.IhateJava();
    }

    public void hello (String string) {
      System.out.println(string);
    }

    @Override
    public void goodbye(String s) {
        System.out.println(s);
    }


    @Override
    public void testInterface(String s) {
        System.out.println(s);
    }
}
