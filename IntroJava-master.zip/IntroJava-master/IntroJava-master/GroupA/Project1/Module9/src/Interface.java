public interface Interface {

   public void hello( String s);
   public void goodbye (String s);
   default public void IhateJava( ){
       System.out.println("I hate Java");
   }
   public static void myStatic() {
       System.out.println("Static interface method");
   }
}
