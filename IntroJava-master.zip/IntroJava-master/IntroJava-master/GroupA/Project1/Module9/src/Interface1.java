public interface Interface1 {
    void testInterface(String s);
}
