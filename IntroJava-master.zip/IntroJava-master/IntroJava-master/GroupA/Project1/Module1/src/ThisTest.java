// Fig. 8.4: ThisTest.java
// this used implicitly and explicitly to refer to members of an object.

public class ThisTest
{
    public static void main(String[] args)
    {
        SimpleTime time = new SimpleTime(-1, 30, 19);
        System.out.println(time.buildString());
    }
} // end class ThisTest

// class SimpleTime demonstrates the "this" reference
