package com.company;
public class Main {

    public static void main(String[] args) {
        System.out.println("Hello from main ");
        System.out.println("Dogs Legs =" + Dog.legs);
        System.out.println("Cats Legs =" + Cat.legs);
        Dog d = new Dog("Wolfhound",6,"Pink");
        System.out.println(d.getAgeC()+" "+d.getColor()+"  "+d.getBreed());
        Dog d1 = new Dog();
        System.out.printf("%d %s  %s%n", d1.getAgeC(), d1.getColor(), d1.getBreed());
        d1.setAgeC(8);
        System.out.printf("%d %s  %s%n", d1.getAgeC(), d1.getColor(), d1.getBreed());
        System.out.print(d);
	// write your code here
    }
}
