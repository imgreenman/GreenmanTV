package com.company;

public class Cat {
    private int age;
    private String color;
    static  public  int legs = 4;

    public Cat(int age, String color) {
        this.age = age;
        this.color = color;
    }

    public Cat() {
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}
