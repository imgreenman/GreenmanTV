package com.company;

public class Dog{
    private String breed;
    private int ageC;
    private String color;
    static public  int legs = 4;

    public Dog(){
        this.breed = "Fox";
        this.ageC = 5;
        this.color = "Yellow";
    }
    public Dog(String breed, int ageC, String color){
// This constructor has one parameter, name.
        this.breed = breed;
        this.ageC = ageC;
        this.color = color;
    }

    public String getBreed() {
        return (breed);
    }
    public String getColor() {
        return (color);
    }
    public int getAgeC() {
        return (ageC);
    }

    public void setBreed( String s){
        this.breed = s;
    }
    public void setColor( String c){
        this.color = c;
    }
    public void setAgeC( int i){
        this.ageC = i;
    }
    void barking(){
    }
    void hungry(){
    }
    void sleeping(){
    }
    public String toString() {
        return ("Hello from tostring method");
    }
}
